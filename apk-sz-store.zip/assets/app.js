// Global State
let APPS = APPS_DATA || [];
let SLIDES = SLIDES_DATA || [];
let CATS = CATS_DATA || [];
let SETTINGS = SETTINGS_DATA || {};
let view = 'home';
let activeCat = '';
let savedApps = JSON.parse(localStorage.getItem('savedApps')) || [];
let isDarkMode = localStorage.getItem('darkMode') === 'true';
let currentShareApp = null;

// Utility function
const $ = id => document.getElementById(id);
const toast = msg => {
  const t = $('toast') || createToast();
  t.innerText = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
};

function createToast() {
  const t = document.createElement('div');
  t.id = 'toast';
  t.className = 'toast';
  document.body.appendChild(t);
  return t;
}

// Theme Toggle
function toggleTheme() {
  isDarkMode = !isDarkMode;
  document.body.classList.toggle('dark', isDarkMode);
  localStorage.setItem('darkMode', isDarkMode);
  updateThemeText();
}

function updateThemeText() {
  const txt = $('themeTxt');
  if (txt) txt.innerText = isDarkMode ? 'Light Mode' : 'Dark Mode';
}

// Initialize theme on load
if (isDarkMode) {
  document.body.classList.add('dark');
}
updateThemeText();

// Drawer Functions
function openDrawer() {
  $('drawerBackdrop').classList.add('show');
}

function closeDrawer(e) {
  if (e && e.target.id !== 'drawerBackdrop') return;
  $('drawerBackdrop').classList.remove('show');
}

function drawerNav(v) {
  view = v;
  closeDrawer();
  renderCurrent();
}

// Search Functions
function openSearch() {
  $('searchOverlay').classList.add('open');
  $('searchInputOverlay').focus();
}

function closeSearch() {
  $('searchOverlay').classList.remove('open');
}

$('searchInput')?.addEventListener('input', (e) => {
  const q = e.target.value.toLowerCase();
  if (!q) return renderCurrent();
  const filtered = APPS.filter(a => (a.name || a.n).toLowerCase().includes(q) || (a.package || '').toLowerCase().includes(q));
  renderAppsList(filtered);
});

// Hero Slider
let slideIdx = 0;

function renderHero() {
  if (!SLIDES || SLIDES.length === 0) return;
  const s = SLIDES[slideIdx];
  const slide = document.querySelector('.slide.active');
  if (slide) {
    slide.innerHTML = `
      <span class="tag">${s.tag}</span>
      <h2>${s.t}</h2>
      <p>${s.p}</p>
    `;
  }
  renderDots();
}

function renderDots() {
  const dots = $('heroDots');
  if (!dots) return;
  dots.innerHTML = SLIDES.map((_, i) => `
    <span class="dot ${i === slideIdx ? 'on' : ''}" onclick="setSlide(${i})"></span>
  `).join('');
}

function setSlide(idx) {
  slideIdx = idx;
  renderHero();
}

setInterval(() => {
  slideIdx = (slideIdx + 1) % (SLIDES.length || 1);
  renderHero();
}, 5000);

// Filtering
function filterCat(cat) {
  activeCat = cat;
  const chips = document.querySelectorAll('.chip');
  chips.forEach(c => c.classList.remove('active'));
  if (cat === '') {
    chips[0]?.classList.add('active');
  } else {
    document.querySelectorAll('.chip').forEach(c => {
      if (c.innerText.trim() === cat) c.classList.add('active');
    });
  }
  
  if (activeCat === '') {
    renderHome();
  } else {
    const filtered = APPS.filter(a => (a.category || a.c) === activeCat);
    renderAppsList(filtered);
  }
}

// Home View
function renderHome() {
  view = 'home';
  $('homeView').classList.remove('hidden');
  $('appsView').classList.add('hidden');
  $('gamesView').classList.add('hidden');
  $('browseView').classList.add('hidden');
  $('adminView').classList.add('hidden');
  
  renderCategories();
  renderAppGrid();
  renderHero();
}

function renderCategories() {
  const chips = $('categoryChips');
  if (!chips) return;
  chips.innerHTML = `
    <div class="chip active" onclick="filterCat('')">All</div>
    ${CATS.map(c => `<div class="chip" onclick="filterCat('${c}')">${c}</div>`).join('')}
  `;
}

function renderAppGrid() {
  const grid = $('appsGrid');
  if (!grid) return;
  grid.innerHTML = APPS.map(a => `
    <div class="app-card" onclick="viewApp('${a.package}')">
      <div class="app-icon">
        <img src="${a.icon || a.i || 'https://via.placeholder.com/54'}" alt="${a.name || a.n}" onerror="this.src='https://via.placeholder.com/54'">
      </div>
      <div class="app-name">${(a.name || a.n || '').substring(0, 20)}</div>
      <div class="app-meta">${a.developer || a.d || 'Developer'}</div>
    </div>
  `).join('');
}

// Apps List View
function renderAppsList(apps = APPS) {
  view = 'apps';
  $('homeView').classList.add('hidden');
  $('appsView').classList.remove('hidden');
  $('gamesView').classList.add('hidden');
  $('browseView').classList.add('hidden');
  $('adminView').classList.add('hidden');
  
  const list = $('appsList');
  if (!list) return;
  list.innerHTML = apps.map(a => `
    <div class="list-row" onclick="viewApp('${a.package}')">
      <div class="list-icon">
        <img src="${a.icon || a.i || 'https://via.placeholder.com/48'}" alt="${a.name || a.n}" onerror="this.src='https://via.placeholder.com/48'">
      </div>
      <div class="list-content">
        <div class="list-title">${a.name || a.n}</div>
        <div class="list-subtitle">${a.developer || a.d || 'Developer'} • v${a.version || a.v || '1.0'}</div>
      </div>
      <button class="list-row dl-btn-sm" onclick="event.stopPropagation()">Get</button>
    </div>
  `).join('');
}

// Games View
function renderGamesView() {
  view = 'games';
  $('homeView').classList.add('hidden');
  $('appsView').classList.add('hidden');
  $('gamesView').classList.remove('hidden');
  $('browseView').classList.add('hidden');
  $('adminView').classList.add('hidden');
  
  const games = APPS.filter(a => (a.category || a.c) === 'Games');
  const list = $('gamesList');
  if (!list) return;
  list.innerHTML = games.map(a => `
    <div class="list-row" onclick="viewApp('${a.package}')">
      <div class="list-icon">
        <img src="${a.icon || a.i || 'https://via.placeholder.com/48'}" alt="${a.name || a.n}" onerror="this.src='https://via.placeholder.com/48'">
      </div>
      <div class="list-content">
        <div class="list-title">${a.name || a.n}</div>
        <div class="list-subtitle">${a.developer || a.d || 'Developer'}</div>
      </div>
      <button class="list-row dl-btn-sm" onclick="event.stopPropagation()">Get</button>
    </div>
  `).join('');
}

function navGo(v) {
  if (v === 'apps') renderAppsList();
  else if (v === 'games') renderGamesView();
  else if (v === 'browse') renderBrowseView();
  else if (v === 'admin') renderAdminView();
}

// Browse Categories View
function renderBrowseView() {
  view = 'browse';
  $('homeView').classList.add('hidden');
  $('appsView').classList.add('hidden');
  $('gamesView').classList.add('hidden');
  $('browseView').classList.remove('hidden');
  $('adminView').classList.add('hidden');
  
  const list = $('categoriesList');
  if (!list) return;
  list.innerHTML = CATS.map(c => {
    const count = APPS.filter(a => (a.category || a.c) === c).length;
    return `
      <div class="list-row" onclick="filterCat('${c}'); view='home'; renderHome()">
        <div style="width: 48px; height: 48px; border-radius: 12px; background: linear-gradient(135deg, #667eea, #764ba2); display: grid; place-items: center; color: white; font-size: 20px; flex-shrink: 0;">
          <i class="fa-solid fa-folder"></i>
        </div>
        <div class="list-content">
          <div class="list-title">${c}</div>
          <div class="list-subtitle">${count} app${count !== 1 ? 's' : ''}</div>
        </div>
      </div>
    `;
  }).join('');
}

// Saved Apps
function showSavedApps() {
  const saved = APPS.filter(a => savedApps.includes(a.package));
  renderAppsList(saved);
}

function toggleSaveApp(pkg) {
  if (savedApps.includes(pkg)) {
    savedApps = savedApps.filter(p => p !== pkg);
    toast('Removed from favorites');
  } else {
    savedApps.push(pkg);
    toast('Added to favorites');
  }
  localStorage.setItem('savedApps', JSON.stringify(savedApps));
}

// View App Details
function viewApp(pkg) {
  const a = APPS.find(x => x.package === pkg);
  if (!a) return;
  currentShareApp = a;
  
  const screenshots = a.screenshots && a.screenshots.length > 0 ? `
    <div class="mt-4">
      <p class="text-xs font-bold mb-2">Screenshots:</p>
      <div class="flex gap-2 overflow-x-auto">
        ${a.screenshots.map(s => `<img src="${s}" alt="Screenshot" class="w-24 h-40 rounded-lg object-cover cursor-pointer" onclick="openLightbox('${s}')">`).join('')}
      </div>
    </div>
  ` : '';

  $('viewContent').innerHTML = `
    <div class="flex items-start gap-4 border-b border-slate-100 pb-4">
      <img src="${a.icon || a.i || 'https://via.placeholder.com/90'}" class="w-16 h-16 rounded-2xl object-cover border">
      <div>
        <h3 class="text-base font-bold text-slate-900 dark:text-white">${a.name || a.n}</h3>
        <p class="text-xs font-mono text-slate-400">${a.package}</p>
        <p class="text-xs text-emerald-600 font-semibold mt-1">${a.developer || a.d} • v${a.version || a.v || '1.0'}</p>
      </div>
    </div>
    <div class="py-4 space-y-3 text-xs text-slate-700 dark:text-slate-300">
      <p><b>Status:</b> ${a.status || 'Available'}</p>
      <p><b>Category:</b> ${a.category || a.c || 'General'}</p>
      <p><b>Package File:</b> ${a.apkName || 'release.apk'} (${a.size || '25 MB'})</p>
      <p><b>Description:</b> ${a.fullDesc || a.desc || 'No description'}</p>
      ${screenshots}
    </div>
  `;
  $('viewModal').classList.remove('hidden');
}

function closeViewModal() {
  $('viewModal').classList.add('hidden');
}

// Lightbox
function openLightbox(src) {
  $('lightboxImg').src = src;
  $('lightboxModal').classList.remove('hidden');
}

function closeLightbox() {
  $('lightboxModal').classList.add('hidden');
}

// Share Functionality
function openShareModal() {
  if (!currentShareApp) return;
  $('shareModal').classList.remove('hidden');
}

function closeShareModal() {
  $('shareModal').classList.add('hidden');
}

function shareToApp(type) {
  if (!currentShareApp) return;
  
  const app = currentShareApp;
  const appName = app.name || app.n;
  const appDev = app.developer || app.d;
  const shareText = `Check out ${appName} by ${appDev} on APK SZ Store! Download now: ${SHARE_URL}`;
  const shareUrl = encodeURIComponent(SHARE_URL);
  const shareTitle = encodeURIComponent(appName);
  
  let url = '';
  
  switch(type) {
    case 'whatsapp':
      url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
      break;
    case 'telegram':
      url = `https://t.me/share/url?url=${shareUrl}&text=${encodeURIComponent(appName)}`;
      break;
    case 'facebook':
      url = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`;
      break;
    case 'twitter':
      url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`;
      break;
    case 'copy':
      navigator.clipboard.writeText(SHARE_URL).then(() => {
        toast('Link copied to clipboard!');
        closeShareModal();
      });
      return;
    case 'native':
      if (navigator.share) {
        navigator.share({
          title: appName,
          text: shareText,
          url: SHARE_URL
        }).catch(err => console.log('Share cancelled'));
      } else {
        alert('Web Share not supported on this device. Use Copy Link instead.');
      }
      closeShareModal();
      return;
  }
  
  if (url) {
    window.open(url, '_blank');
    closeShareModal();
  }
}

// Privacy Modal
function openPrivacyModal() {
  $('privacyContent').innerHTML = (SETTINGS.privacy || 'No privacy policy available').replace(/\n/g, '<br>');
  $('privacyModal').classList.remove('hidden');
}

function closePrivacyModal() {
  $('privacyModal').classList.add('hidden');
}

// Request App Modal
function requestAppModal() {
  $('requestModal').classList.remove('hidden');
}

function closeRequestModal() {
  $('requestModal').classList.add('hidden');
}

function submitRequest(e) {
  e.preventDefault();
  const appName = $('req_app_name').value;
  toast(`Request for "${appName}" submitted! We'll review it soon.`);
  $('requestModal').classList.add('hidden');
  document.querySelector('#requestModal form').reset();
}

// Admin Console
function renderAdminView() {
  view = 'admin';
  $('homeView').classList.add('hidden');
  $('appsView').classList.add('hidden');
  $('gamesView').classList.add('hidden');
  $('browseView').classList.add('hidden');
  $('adminView').classList.remove('hidden');
  
  adminTab('apps');
  renderAdminApps();
  renderAdminBanners();
  renderAdminCategories();
  loadAdminSettings();
}

function adminTab(tab) {
  document.querySelectorAll('[id*="adminBtn"]').forEach(b => b.classList.add('bg-slate-300') || b.classList.remove('bg-blue-600', 'text-white'));
  document.querySelectorAll('[id*="Tab"]').forEach(t => t.classList.add('hidden'));
  
  if (tab === 'apps') {
    $('adminAppsBtn').classList.remove('bg-slate-300');
    $('adminAppsBtn').classList.add('bg-blue-600', 'text-white');
    $('adminAppsTab').classList.remove('hidden');
  } else if (tab === 'banners') {
    $('adminBannersBtn').classList.remove('bg-slate-300');
    $('adminBannersBtn').classList.add('bg-blue-600', 'text-white');
    $('adminBannersTab').classList.remove('hidden');
  } else if (tab === 'categories') {
    $('adminCatsBtn').classList.remove('bg-slate-300');
    $('adminCatsBtn').classList.add('bg-blue-600', 'text-white');
    $('adminCatsTab').classList.remove('hidden');
  } else if (tab === 'settings') {
    $('adminSettingsBtn').classList.remove('bg-slate-300');
    $('adminSettingsBtn').classList.add('bg-blue-600', 'text-white');
    $('adminSettingsTab').classList.remove('hidden');
  }
}

function renderAdminApps() {
  const list = $('adminAppsList');
  if (!list) return;
  list.innerHTML = APPS.map((a, idx) => `
    <div class="bg-slate-100 dark:bg-slate-700 p-3 rounded-lg mb-2 flex items-center justify-between">
      <div>
        <div class="text-sm font-bold">${a.name || a.n}</div>
        <div class="text-xs text-slate-500">${a.package}</div>
      </div>
      <button onclick="deleteAdminApp(${idx})" class="text-red-600 font-bold text-sm">Delete</button>
    </div>
  `).join('');
}

function addAppForm(e) {
  e.preventDefault();
  const app = {
    id: 'app_' + Date.now(),
    name: $('app_name').value,
    package: $('app_package').value,
    icon: $('app_icon').value,
    developer: $('app_developer').value,
    category: $('app_category').value,
    version: $('app_version').value,
    size: $('app_size').value,
    apkName: $('app_apkname').value,
    desc: $('app_desc').value,
    fullDesc: $('app_fulldesc').value,
    status: $('app_status').value
  };
  
  APPS.push(app);
  localStorage.setItem('sz_apps_local', JSON.stringify(APPS));
  toast('App added successfully!');
  e.target.reset();
  renderAdminApps();
}

function deleteAdminApp(idx) {
  if (confirm('Delete this app?')) {
    APPS.splice(idx, 1);
    localStorage.setItem('sz_apps_local', JSON.stringify(APPS));
    renderAdminApps();
    toast('App deleted');
  }
}

function renderAdminBanners() {
  const grid = $('admBannerGrid');
  if (!grid) return;
  grid.innerHTML = SLIDES.map((s, idx) => `
    <div class="p-4 rounded-2xl border relative overflow-hidden" style="background:${s.g}">
      <span class="text-[9px] font-extrabold uppercase bg-white/20 px-2 py-0.5 rounded-full text-white">${s.tag}</span>
      <h4 class="text-sm font-extrabold text-white mt-1">${s.t}</h4>
      <p class="text-xs text-white/80">${s.p}</p>
      <button onclick="deleteBanner(${idx})" class="absolute top-3 right-3 bg-red-600 text-white p-1 rounded-lg text-xs"><i class="fa-solid fa-trash"></i></button>
    </div>
  `).join('') || '<p class="text-slate-400 text-xs">No banners added</p>';
}

function openBannerModal() {
  $('bannerModal').classList.remove('hidden');
}

function saveBannerSlide() {
  const slide = {
    id: 's_' + Date.now(),
    tag: $('b_tag').value.trim() || 'Featured',
    t: $('b_t').value.trim() || 'New Promo',
    p: $('b_p').value.trim() || 'Special store release',
    g: $('b_g').value
  };
  
  SLIDES.push(slide);
  localStorage.setItem('sz_slides_local', JSON.stringify(SLIDES));
  $('bannerModal').classList.add('hidden');
  renderAdminBanners();
  toast('Banner added');
  document.querySelectorAll('#bannerModal input, #bannerModal textarea').forEach(f => f.value = '');
}

function deleteBanner(idx) {
  SLIDES.splice(idx, 1);
  localStorage.setItem('sz_slides_local', JSON.stringify(SLIDES));
  renderAdminBanners();
}

function renderAdminCategories() {
  const chips = $('admCategoryChips');
  if (!chips) return;
  chips.innerHTML = CATS.map((c, idx) => `
    <div class="bg-slate-100 dark:bg-slate-700 border text-slate-700 dark:text-white px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
      <span>${c}</span>
      <button onclick="deleteCategory(${idx})" class="text-rose-500 font-bold">✕</button>
    </div>
  `).join('');
}

function addCategory() {
  const val = $('newCatInput').value.trim();
  if (!val) return;
  if (!CATS.includes(val)) {
    CATS.push(val);
    localStorage.setItem('sz_cats_local', JSON.stringify(CATS));
    renderAdminCategories();
    renderCategories();
    toast('Category added');
    $('newCatInput').value = '';
  }
}

function deleteCategory(idx) {
  CATS.splice(idx, 1);
  localStorage.setItem('sz_cats_local', JSON.stringify(CATS));
  renderAdminCategories();
  renderCategories();
}

function loadAdminSettings() {
  $('set_telegram').value = SETTINGS.telegram || '';
  $('set_youtube').value = SETTINGS.youtube || '';
  $('set_notice').value = SETTINGS.notice || '';
  $('set_privacy').value = SETTINGS.privacy || '';
}

function saveSocialSettings() {
  SETTINGS.telegram = $('set_telegram').value.trim();
  SETTINGS.youtube = $('set_youtube').value.trim();
  SETTINGS.notice = $('set_notice').value.trim();
  
  localStorage.setItem('sz_settings_local', JSON.stringify(SETTINGS));
  
  if (SETTINGS.telegram) $('drawerTelegramLink').href = SETTINGS.telegram;
  if (SETTINGS.youtube) $('drawerYoutubeLink').href = SETTINGS.youtube;
  
  toast('Social settings saved!');
}

function savePrivacyPolicy() {
  SETTINGS.privacy = $('set_privacy').value.trim();
  localStorage.setItem('sz_settings_local', JSON.stringify(SETTINGS));
  toast('Privacy Policy updated!');
}

function closeModal(id) {
  $(id).classList.add('hidden');
}

// Initialize
function init() {
  renderHome();
}

// Check if page is already loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
